import numpy as np
import matplotlib.pyplot as plt
import os.path



directory = os.path.dirname(os.path.abspath(__file__)) 
#directory += '\\Data Project'

fatality = []
wealth = []
county = []   

filename = os.path.join(directory, 'fatalities.txt')
datafile = open(filename, 'r')

for line in datafile:
    part, fatal = line.split(',')
    fatality.append(fatal)
    county.append(part)
datafile.close()

filename = os.path.join(directory, 'Income Per Household.txt')
datafile = open(filename, 'r')

for line in datafile:
    part, income = line.split(',')
    wealth.append(income)

y = fatality
x = wealth


#colors = list(range(1,57))
area = np.pi * (15)  # size of circles

    
fig, (ax1,ax2) = plt.subplots(1,2)

for i, txt in enumerate(county):
    ax1.annotate(txt, (x[i],y[i]))
    ax2.annotate(txt, (x[i],y[i]))

    
ax1.scatter(x, y, s=area, c='r', alpha=0.5)
ax2.scatter(x, y, s=area, c='g', alpha=0.5)

ax1.set_xlabel('Medium Household Income in Each County')
ax1.set_ylabel('Number of Crashes per Year')
ax2.set_xlabel('Medium Household Income in Each County')
ax2.set_ylabel('Number of Crashes per Year')

ax1.set_title('Wealth of County in California vs. Number of Car Crashes')
ax2.set_title('Wealth of County in California vs. Number of Car Crashes (Zoomed in)')

ax2.set_ylim(0, 60)
ax2.set_xlim(30000, 100000)

fig.show()
